        </main>
        <footer style="text-align: center; padding: 20px; margin-top: 40px; color: var(--gray-500); font-size: 13px; border-top: 1px solid var(--gray-200);">
            FA Auction v<?php echo getCurrentVersion(); ?>
        </footer>
    </div>
    <script src="<?php echo getBaseUrl(); ?>/assets/js/app.js"></script>
</body>
</html>
